#!/bin/bash
set -e

# ============================================================
# Linux Server Administration + Bash Automation Project
# Ubuntu 22.04 / 24.04
# Installs:
# Apache + PHP + MySQL + Bash automation
# Prometheus + Node Exporter + Grafana
# ============================================================

if [ "$EUID" -ne 0 ]; then
  echo "Please run this script with sudo:"
  echo "sudo bash setup_linux_project.sh"
  exit 1
fi

echo "=============================================="
echo " Linux LAMP + Bash + Prometheus + Grafana"
echo "=============================================="

export DEBIAN_FRONTEND=noninteractive

echo "[1/12] Updating Ubuntu..."
apt-get update -y
apt-get upgrade -y

echo "[2/12] Installing LAMP stack..."
apt-get install -y apache2 mysql-server php libapache2-mod-php php-mysql curl wget tar gnupg ca-certificates apt-transport-https software-properties-common

systemctl enable --now apache2
systemctl enable --now mysql

echo "[3/12] Creating MySQL database..."
mysql <<'SQL'
CREATE DATABASE IF NOT EXISTS lampdb;
CREATE USER IF NOT EXISTS 'lampuser'@'localhost' IDENTIFIED BY 'Password@123';
ALTER USER 'lampuser'@'localhost' IDENTIFIED BY 'Password@123';
GRANT ALL PRIVILEGES ON lampdb.* TO 'lampuser'@'localhost';
FLUSH PRIVILEGES;
SQL

echo "[4/12] Creating sample PHP application..."
cat > /var/www/html/index.php <<'PHP'
<?php
$db = new mysqli("localhost", "lampuser", "Password@123", "lampdb");

echo "<!DOCTYPE html>";
echo "<html><head><title>LAMP DevOps Project</title>";
echo "<style>body{font-family:Arial;margin:50px} .ok{color:green}</style>";
echo "</head><body>";
echo "<h1>Linux LAMP Application</h1>";
echo "<p class='ok'>Apache: Running</p>";
echo "<p class='ok'>PHP: Running</p>";

if ($db->connect_error) {
    echo "<p style='color:red'>MySQL: Connection Failed</p>";
} else {
    echo "<p class='ok'>MySQL: Connected</p>";
    $db->close();
}

echo "<hr><p>Server time: " . date("Y-m-d H:i:s") . "</p>";
echo "</body></html>";
?>
PHP

chown -R www-data:www-data /var/www/html
chmod 755 /var/www/html
systemctl restart apache2

echo "[5/12] Creating automation scripts..."

mkdir -p /opt/linux-server-project/backups
mkdir -p /opt/linux-server-project/scripts
mkdir -p /opt/linux-server-project/logs

cat > /opt/linux-server-project/scripts/backup.sh <<'BASH'
#!/bin/bash
set -e

DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_DIR="/opt/linux-server-project/backups"

mkdir -p "$BACKUP_DIR"

tar -czf "$BACKUP_DIR/html_$DATE.tar.gz" /var/www/html
mysqldump lampdb > "$BACKUP_DIR/lampdb_$DATE.sql"

find "$BACKUP_DIR" -type f -mtime +7 -delete

echo "$(date): Backup completed successfully."
BASH

cat > /opt/linux-server-project/scripts/log_cleanup.sh <<'BASH'
#!/bin/bash

LOG_DIR="/var/log"

find "$LOG_DIR" -type f -name "*.log" -mtime +7 -delete

echo "$(date): Old log files cleaned."
BASH

cat > /opt/linux-server-project/scripts/health_check.sh <<'BASH'
#!/bin/bash

LOG="/opt/linux-server-project/logs/health.log"

{
echo "======================================"
echo "Linux Server Health Check"
echo "Date: $(date)"
echo "======================================"

echo "--- CPU / Load ---"
uptime

echo "--- Memory ---"
free -h

echo "--- Disk ---"
df -h /

echo "--- Apache ---"
systemctl is-active apache2 || true

echo "--- MySQL ---"
systemctl is-active mysql || true

echo "--- Node Exporter ---"
systemctl is-active prometheus-node-exporter || true

echo "--- Prometheus ---"
systemctl is-active prometheus || true

echo "--- Grafana ---"
systemctl is-active grafana-server || true

echo
} >> "$LOG"

cat "$LOG"
BASH

chmod +x /opt/linux-server-project/scripts/*.sh

ln -sf /opt/linux-server-project/scripts/backup.sh /usr/local/bin/backup.sh
ln -sf /opt/linux-server-project/scripts/log_cleanup.sh /usr/local/bin/log_cleanup.sh
ln -sf /opt/linux-server-project/scripts/health_check.sh /usr/local/bin/health_check.sh

echo "[6/12] Configuring daily Cron jobs..."
CRON1="0 2 * * * /usr/local/bin/backup.sh >> /opt/linux-server-project/logs/backup.log 2>&1"
CRON2="0 3 * * * /usr/local/bin/log_cleanup.sh >> /opt/linux-server-project/logs/log_cleanup.log 2>&1"
CRON3="0 * * * * /usr/local/bin/health_check.sh"

( crontab -l 2>/dev/null | grep -vF "/usr/local/bin/backup.sh" || true
  echo "$CRON1"
  crontab -l 2>/dev/null | grep -vF "/usr/local/bin/log_cleanup.sh" || true
  echo "$CRON2"
  crontab -l 2>/dev/null | grep -vF "/usr/local/bin/health_check.sh" || true
  echo "$CRON3"
) | awk '!seen[$0]++' | crontab -

echo "[7/12] Installing Node Exporter..."
apt-get install -y prometheus-node-exporter
systemctl enable --now prometheus-node-exporter

echo "[8/12] Installing Prometheus..."
apt-get install -y prometheus

PROM_CFG="/etc/prometheus/prometheus.yml"
cp "$PROM_CFG" "${PROM_CFG}.backup.$(date +%s)" 2>/dev/null || true

cat > "$PROM_CFG" <<'YAML'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: "ubuntu-server"
    static_configs:
      - targets: ["localhost:9100"]
YAML

systemctl enable --now prometheus
systemctl restart prometheus

echo "[9/12] Installing Grafana..."
mkdir -p /etc/apt/keyrings
wget -q -O /etc/apt/keyrings/grafana.gpg https://apt.grafana.com/gpg.key
chmod 644 /etc/apt/keyrings/grafana.gpg

echo "deb [signed-by=/etc/apt/keyrings/grafana.gpg] https://apt.grafana.com stable main" \
  > /etc/apt/sources.list.d/grafana.list

apt-get update -y
apt-get install -y grafana

systemctl enable --now grafana-server

echo "[10/12] Opening firewall ports if UFW is active..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
    ufw allow 80/tcp
    ufw allow 3000/tcp
    ufw allow 9090/tcp
fi

echo "[11/12] Running tests..."
echo "--- Apache ---"
systemctl is-active apache2

echo "--- MySQL ---"
systemctl is-active mysql

echo "--- PHP ---"
php --version | head -1

echo "--- Node Exporter ---"
curl -s http://localhost:9100/metrics | head -2 || true

echo "--- Prometheus ---"
curl -s http://localhost:9090/-/healthy || true
echo

echo "--- Grafana ---"
systemctl is-active grafana-server

echo "[12/12] Running first backup..."
/usr/local/bin/backup.sh

IP=$(hostname -I | awk '{print $1}')

echo
echo "=============================================="
echo " INSTALLATION COMPLETED"
echo "=============================================="
echo "Application : http://$IP"
echo "Prometheus  : http://$IP:9090"
echo "Grafana     : http://$IP:3000"
echo
echo "Grafana default login is commonly:"
echo "Username: admin"
echo "Password: admin"
echo "You may be asked to change it on first login."
echo
echo "Scripts:"
echo "  backup.sh"
echo "  log_cleanup.sh"
echo "  health_check.sh"
echo
echo "Project directory:"
echo "  /opt/linux-server-project"
echo "=============================================="

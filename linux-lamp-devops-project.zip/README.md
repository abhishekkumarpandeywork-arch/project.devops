# Linux Server Administration and Bash Automation

## What this project deploys

- Ubuntu Linux server
- Apache web server
- PHP application
- MySQL database
- Bash automation
  - Daily application/database backups
  - Log cleanup
  - Hourly health monitoring
- Prometheus
- Node Exporter
- Grafana

## Run

Copy `setup_linux_project.sh` to your Ubuntu Server and run:

```bash
chmod +x setup_linux_project.sh
sudo bash setup_linux_project.sh
```

After installation, the script prints your server IP.

Open:

- `http://SERVER_IP` — LAMP application
- `http://SERVER_IP:9090` — Prometheus
- `http://SERVER_IP:3000` — Grafana

## Useful commands

```bash
sudo systemctl status apache2
sudo systemctl status mysql
sudo systemctl status prometheus-node-exporter
sudo systemctl status prometheus
sudo systemctl status grafana-server
```

Run automation manually:

```bash
sudo backup.sh
sudo log_cleanup.sh
sudo health_check.sh
```

Backups are stored in:

```text
/opt/linux-server-project/backups
```

Logs are stored in:

```text
/opt/linux-server-project/logs
```

## Important

This is a learning/lab deployment. Change the sample MySQL password before using it in a real environment. Do not expose MySQL directly to the internet.

## Grafana

After opening Grafana, add Prometheus as a data source:

```text
Connections → Data sources → Add data source → Prometheus
```

Use:

```text
http://localhost:9090
```

Then create/import a Node Exporter dashboard for CPU, memory, disk and other Linux metrics.
